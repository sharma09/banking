
        <footer>
            <div class="container">
                <!-- I worked hard to design this template. So please don't remove the below link. If you remove then you are breaking the licence. -->
                <p class="pull-left">Copyright &copy; 2019 - <a href="#">Banking website</a></p><p class="pull-right attr">Designed by <a href="#">Gaurav Thakur</a></p>
                <div class="clearfix"></div>
            </div>
        </footer>
    </div>
    </body>
</html>
